//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by 陈汉超 on 2021/5/24.
//

import SwiftUI

@main
struct LandmarksApp: App {
    @StateObject private var modelData = ModelData()
    var body: some Scene {
       let mainWindows =  WindowGroup {
            ContentView()
                .environmentObject(modelData)
        }
        #if os(macOS)
        mainWindows.commands{
            LandmarkCommands()
        }
        #else
        mainWindows
        #endif
        
        
        #if os(watchOS)
        WKNotificationScene(controller: NotificationController.self, category: "LandmarkNear")
        #endif
        
        #if os(macOS)
        Settings{
            LandmarkSettings()
        }
        #endif
    }
}
