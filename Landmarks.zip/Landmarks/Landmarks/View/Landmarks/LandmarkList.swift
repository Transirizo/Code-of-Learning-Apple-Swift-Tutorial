//
//  LandmarksList.swift
//  Landmarks
//
//  Created by 陈汉超 on 2021/5/24.
//  Copyright © 2021 Apple. All rights reserved.
//

import SwiftUI

struct LandmarkList: View {
    @State private var showFavoriteOnly = false
    @EnvironmentObject var modelData: ModelData
    @State private var filter = FilterCategory.all
    @State private var selectedLandmark: Landmark?
    enum FilterCategory: String, CaseIterable, Identifiable {
        case all = "All"
        case lakes = "Lakes"
        case mountains = "Mountains"
        case Rivers = "Rivers"
        
        var id: FilterCategory { self }
    }
    
    var filteredLandmarks:[Landmark]{
        modelData.landmarks.filter { landmark in
            (!showFavoriteOnly || landmark.isFavorite) && (filter == .all || filter.rawValue == landmark.category.rawValue)
        }
    }
    
    var title: String {
        let title = filter == .all ? "Landmarks" : filter.rawValue
        return  showFavoriteOnly ? "Favorite\(title)" : title
    }
    
    var index: Int? {
        modelData.landmarks.firstIndex(where:{$0.id == selectedLandmark?.id})
    }
    
    var body: some View {
            NavigationView{
                List(selection: $selectedLandmark) {
                    ForEach(filteredLandmarks){ landmark in
                        NavigationLink(destination:LandmarkDetail(landmark:landmark)){
                            LandmarkRow(landmark: landmark)
                        }
                        
                    }
                }
                .navigationTitle(title)
                .frame(minWidth: 300)
                .toolbar {
                    ToolbarItem{
                        Menu{
                            Picker("Category", selection: $filter){
                                ForEach(FilterCategory.allCases){ category in
                                    Text(category.rawValue).tag(category)
                                }
                            }
                            .pickerStyle(InlinePickerStyle())
                            
                            Toggle(isOn: $showFavoriteOnly){
                                Label("Favorite Only", systemImage: "star.fill")
                            }
                        } label: {
                            Label("Filter", systemImage: "slider.horizontal.3")
                        }
                    }
                }
                Text("Select a Landmark")
            }
            .focusedValue(\.selectedLandmark, $modelData.landmarks[index ?? 0])
    }
}

struct LandmarkList_Previews: PreviewProvider {
    static var previews: some View {
        LandmarkList()
            .environmentObject(ModelData())
    }
}
